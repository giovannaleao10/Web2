package model;

public class User {
    private String email;
    private String password;

    // Construtor
    public User(String email, String password) {
        this.email = email;
        this.password = password;
    }

    // Métodos Getters
    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    // Método para autenticação
    public boolean isValidUser() {
        // Email e senha pré-definidos
        return this.email.equals("admin@ifsp.edu.br") && this.password.equals("123456");
    }
}