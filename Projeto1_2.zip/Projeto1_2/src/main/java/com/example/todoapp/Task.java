// Pacote onde a classe está (ajuste conforme seu projeto)
package com.example.todoapp;

// Importação para usar o tipo Date
import java.util.Date;

// Definição da classe Task
public class Task {
    private int id;              // ID da tarefa
    private String description;  // Descrição da tarefa
    private Date date;           // Data da tarefa

    // Construtor da classe (para inicializar uma tarefa)
    public Task(int id, String description, Date date) {
        this.id = id;
        this.description = description;
        this.date = date;
    }

    // Getters e setters (para acessar e modificar os atributos)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}

